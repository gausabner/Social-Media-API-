const express = require('express');
const app = express();
const session = require('express-session');
const hbs = require('express-handlebars');
const mongoose = require('mongoose');
const passport = require('passport');
const localStrategy = require('passport-local');
const bcrypt = require('bcrypt');
const dotenv = require('dotenv');
const morgan = require('morgan');
const helmet = require('helmet');
const userRoute = require("./routes/users");
const authRoute = require("./routes/auth");
const postRoute = require("./routes/posts");

dotenv.config();

//connect to local database
mongoose.connect("mongodb://localhost:27017/WIC", {
    useNewUrlParser: true,
    useUnifiedTopology: true },
    () => {
        console.log('Connected to local Mongo Database');
    }
);

//Middleware
app.use(express.json());
app.use(helmet());
app.use(morgan("common"));
app.use('/api/users', userRoute);
app.use('/api/auth', authRoute);
app.use('/api/posts', postRoute);


//Start server listening on port 3000
app.listen(3000, () => {
    console.log(`Server started on port 3000`);
});



