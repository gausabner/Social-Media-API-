const mongoose = require('mongoose');

const PostSchema = new mongoose.Schema({
    userId:{
        type:String,
        require: true,
    },

    description:{
        type:String,
        require: true,
        max:500,
    },

    image:{
        type:String,
    },

    likes:{
        type:Array,
        default:[],
    },
},

{timestamps: true} //update timestamp whenever a new user is created or updated

);

module.exports = mongoose.model("Post", PostSchema); //export UserSchema