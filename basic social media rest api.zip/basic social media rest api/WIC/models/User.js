const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    username:{
        type:String,
        require: true,
        min:2, //minimum characters
        max:30, //maximum characters
        unique: true //to prevent duplicate usernames
    },

    email:{
        type:String,
        require: true,
        min:6,
    },

    password:{
        type:String,
        require: true,
        min:8,
    },

    profilePicture:{
        type:String,
        default:"",
    },

    coverPicture:{
        type:String,
        default:"",
    },
    followers:{
        type:Array,
        default:[],
    },
    following:{
        type:Array,
        default:[],
    },
    isAdmin:{
        type:Boolean,
        default: false,
    },
    description:{
        type:String,
        maximum:80,
    },
    city:{
        type:String,
        max:50,
    },
    country:{
        type:String,
        max:50,
    },
},

{timestamps: true} //update timestamp whenever a new user is created or updated

);

module.exports = mongoose.model("User", UserSchema); //export UserSchema