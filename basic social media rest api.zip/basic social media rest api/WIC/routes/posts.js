const router = require('express').Router();
const Post = require('../models/Post');
const User = require('../models/User');

//create a post
router.post("/", async (req, res) =>{
    const newPost = new Post(req.body);
    try{
        const savePost = await newPost.save();
        res.status(200).json(savePost);
    }catch(err){
        res.status(500).json(err);
    }
});

//update a post
router.put("/:id", async (req, res) =>{
    try{

        //verify userid
        const post = await Post.findById(req.params.id);
        //verify owner of post
        if(post.userId === req.body.userId){
            await post.updateOne({ $set: req.body });
            res.status(200).json("Post updated successfully");
        }else{
            res.status(403).json("You can only update your own post");
        }

    } catch(err) {
        res.status(500).json(err);
    }
});

//delete a post
router.delete("/:id", async (req, res) =>{
    try{

        //find post by id
        const post = await Post.findById(req.params.id);
        //verify owner of post
        if(post.userId === req.body.userId){
            await post.deleteOne();
            res.status(200).json("Post deleted successfully");
        }else{
            res.status(403).json("You can only delete your own post");
        }

    } catch(err) {
        res.status(500).json(err);
    }
});

//like a post
router.put("/:id/like", async (req, res) =>{
    try{
        //find post by id
        const post = await Post.findById(req.params.id);
        if(!post.likes.includes(req.body.userId)){
            await post.updateOne({ $push: { likes: req.body.userId } });
            res.status(200).json("Post liked");
        } else {
            await post.updateOne({ $pull: { likes: req.body.userId } });
            res.status(200).json("Post disliked");
        }

    } catch(err) {
        res.status(500).json(err);
    }
});

//get a post
router.get("/:id", async (req, res) =>{
    try{
        //find post by id
        const post = await Post.findById(req.params.id);
        res.status(200).json(post);

    } catch(err) {
        res.status(500).json(err);
    }
});

//get all posts of followings for the timeline
router.get("/timeline/all", async (req, res) =>{
    try{
        //find current user
        const currentUser = await User.findById(req.body.userId);
        //find all posts of current user
        const userPosts = await Post.find({ userId: currentUser._id });
        //find all posts of accounts the current user is following
        const friendPosts = await Promise.all(
            currentUser.following.map((friendId) => {
               return Post.find({userId:friendId});
            }));
        res.json(userPosts.concat(...friendPosts));

    } catch (err) {
        res.status(500).json(err);
    }
});



module.exports = router;